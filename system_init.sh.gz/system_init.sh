#!/bin/bash

# --- 配置文件创建：/etc/udev/rules.d/10-network.rules ---
if ! grep -q '00:23:12:21:d8:ae' /etc/udev/rules.d/10-network.rules; then
  echo 'SUBSYSTEM=="net", ACTION=="add", ATTR{address}=="00:23:12:21:d8:ae", NAME="eth0"' > /etc/udev/rules.d/10-network.rules
fi

# --- 配置文件创建：/etc/sysconfig/network-scripts/ifcfg-eth0 ---
if ! grep -q 'IPADDR=192.168.6.11' /etc/sysconfig/network-scripts/ifcfg-eth0; then
  cat << EOF | sudo tee /etc/sysconfig/network-scripts/ifcfg-eth0
BOOTPROTO=static
NAME=eth0
DEVICE=eth0
ONBOOT=yes
IPADDR=192.168.6.11
NETMASK=255.255.255.0
GATEWAY=192.168.6.1
DNS1=192.168.6.1
EOF
fi

# --- 配置文件创建：/etc/profile ---
if ! grep -q 'export HISTTIMEFORMAT' /etc/profile; then
  cat <<EOF >> /etc/profile
export HISTTIMEFORMAT="%F %T \$(whoami) "
export M2_HOME=/usr/local/maven/apache-maven-3.9.11
export MAVEN_HOME=/usr/local/maven/apache-maven-3.9.11
export JAVA_HOME=/usr/local/java/jdk-17.0.12
export PATH=\$PATH:\$JAVA_HOME/bin:\$MAVEN_HOME/bin
EOF
fi

# --- 配置文件创建：/etc/profile.d/env.sh ---
if ! grep -q 'PS1' /etc/profile.d/env.sh; then
  cat <<EOF >> /etc/profile.d/env.sh
PS1="\[\e[1;32m\][\[\e[0m\]\t \[\e[1;33m\]\u\[\e[36m\]@\h\[\e[1;31m\] \W\[\e[1;32m\]]\[\e[0m\]\\$"
EOF
fi

# --- 配置文件创建：/root/.vimrc ---
if ! grep -q 'set ignorecase' /root/.vimrc; then
  cat <<EOF >> /root/.vimrc
set ignorecase
set cursorline
set autoindent
set paste
EOF
fi

# --- 更新系统 ---
dnf update -y

# --- 安装必需的工具 ---
dnf install -y vim wget curl tar zip unzip net-tools iproute traceroute nmap telnet lsof tcpdump \
  procps-ng dstat sysstat git make gcc gcc-c++ perl nodejs vim-enhanced sudo epel-release systemd \
  firewalld chrony lrzsz tree bash-completion psmisc httpd-tools glibc glibc-devel pcre pcre-devel \
  openssl openssl-devel zlib-devel libevent-devel bc systemd-devel htop iotop iftop

# --- 安装 Java 和 Maven ---
if [ ! -d "/usr/local/java/jdk-17.0.12" ]; then
  wget https://download.oracle.com/java/17/archive/jdk-17.0.12_linux-x64_bin.tar.gz
  tar -xvf jdk-17.0.12_linux-x64_bin.tar.gz
  sudo mkdir -p /usr/local/java
  sudo mv jdk-17.0.12 /usr/local/java/
  rm -f jdk-17.0.12_linux-x64_bin.tar.gz
fi

if [ ! -d "/usr/local/maven/apache-maven-3.9.11" ]; then
  wget https://dlcdn.apache.org/maven/maven-3/3.9.11/binaries/apache-maven-3.9.11-bin.tar.gz
  tar -xvf apache-maven-3.9.11-bin.tar.gz
  sudo mkdir -p /usr/local/maven
  sudo mv apache-maven-3.9.11 /usr/local/maven/
  rm -f apache-maven-3.9.11-bin.tar.gz
fi

# --- 更新 GRUB 配置以禁用网络接口名称 ---
if ! grep -q 'net.ifnames=0 biosdevname=0' /etc/default/grub; then
  echo 'GRUB_CMDLINE_LINUX="net.ifnames=0 biosdevname=0"' >> /etc/default/grub
  grub2-mkconfig -o /boot/grub2/grub.cfg
fi

# --- 获取并更新网络接口的 MAC 地址 ---
mac_address=$(ip a | grep eth | tr -s " " | cut -d " " -f3 | tail -n +2 | head -1)

if [ -n "$mac_address" ]; then
  sed -i '/SUBSYSTEM=="net", ACTION=="add", ATTR{address}==/s/\([0-9a-fA-F][0-9a-fA-F]:\)\{5\}[0-9a-fA-F][0-9a-fA-F]/'"${mac_address}"'/g' /etc/udev/rules.d/10-network.rules
else
  echo "No MAC address found. Skipping MAC address update."
fi

# --- 用户输入新的 IP 地址，避免重复修改相同的 IP ---
read -p "Enter Your IP: " ip
if [ "$ip" != "11" ]; then
  sed -i "s#^IPADDR=.*#IPADDR=192.168.6.${ip}#g" /etc/sysconfig/network-scripts/ifcfg-eth0
else
  echo "IP address is already set to 192.168.6.11, skipping IP change."
fi

# --- 如果 SSH 密钥已存在，则跳过密钥生成步骤 ---
if [ ! -f /root/.ssh/id_rsa ]; then
  echo "SSH key does not exist. Generating SSH key..."
  ssh-keygen -t rsa -b 4096 -N "" -f /root/.ssh/id_rsa -C "root@$(hostname)"
else
  echo "SSH key already exists. Skipping SSH key generation."
fi

# --- 将 SSH 公钥添加到 authorized_keys 中 ---
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys

# --- 提示重启 ---
echo "Rebooting after 3 seconds..."
for i in {3..1}; do
  echo "$i"
  sleep 1
done

echo "Reboot Now!"
reboot

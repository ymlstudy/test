#!/bin/bash
cat << EOF > /etc/udev/rules.d/10-network.rules
SUBSYSTEM=="net", ACTION=="add", ATTR{address}=="00:23:12:21:d8:ae", NAME="eth0"
EOF

cat <<EOF | sudo tee /etc/sysconfig/network-scripts/ifcfg-eth0
BOOTPROTO=static
NAME=eth0
DEVICE=eth0
ONBOOT=yes
IPADDR=192.168.6.11
NETMASK=255.255.255.0
GATEWAY=192.168.6.1
DNS1=192.168.6.1
EOF

cat  >> /etc/profile <<EOF
export HISTTIMEFORMAT="%F %T `whoami` "
export M2_HOME=/usr/local/maven/apache-maven-3.9.11
export MAVEN_HOME=/usr/local/maven/apache-maven-3.9.11
export JAVA_HOME=/usr/local/java/jdk-17.0.12
export PATH=$PATH:$JAVA_HOME/bin:$MAVEN_HOME/bin
EOF


cat  >> /etc/profile.d/env.sh <<EOF
PS1="\[\e[1;32m\][\[\e[0m\]\t \[\e[1;33m\]\u\[\e[36m\]@\h\[\e[1;31m\] \W\[\e[1;32m\]]\[\e[0m\]\\$"
EOF

cat  >> /root/.vimrc <<EOF
set ignorecase                                                                                                                                 
set cursorline
set autoindent
set paste
EOF


dnf install -y vim wget curl tar zip unzip net-tools iproute traceroute nmap telnet lsof tcpdump  procps-ng dstat sysstat git make gcc gcc-c++ perl   nodejs vim-enhanced sudo epel-release systemd firewalld chrony lrzsz tree bash-completion psmisc httpd-tools glibc glibc-devel pcre pcre-devel  openssl  openssl-devel zlib-devel libevent-devel bc systemd-devel htop iotop iftop



wget https://download.oracle.com/java/17/archive/jdk-17.0.12_linux-x64_bin.tar.gz
tar -xvf jdk-17.0.12_linux-x64_bin.tar.gz
sudo mkdir -p /usr/local/java
sudo mv jdk-17.0.12 /usr/local/java/
wget https://dlcdn.apache.org/maven/maven-3/3.9.11/binaries/apache-maven-3.9.11-bin.tar.gz
tar -xvf apache-maven-3.9.11-bin.tar.gz
sudo mkdir -p /usr/local/maven
sudo mv apache-maven-3.9.11 /usr/local/maven/
rm -rf linux-x64_bin.tar.gz apache-maven-3.9.11-bin.tar.gz jdk-17.0.12 apache-maven-3.9.11


# 更新 GRUB 配置以禁用网络接口名称
echo 'GRUB_CMDLINE_LINUX="net.ifnames=0 biosdevname=0"' >> /etc/default/grub
grub2-mkconfig -o /boot/grub2/grub.cfg

# 获取并更新网络接口的 MAC 地址
mac_address=$(ip a | grep eth | tr -s " " | cut -d " " -f3 | tail -n +2 | head -1)

if [ -n "$mac_address" ]; then
  sed -i '/SUBSYSTEM=="net", ACTION=="add", ATTR{address}==/s/\([0-9a-fA-F][0-9a-fA-F]:\)\{5\}[0-9a-fA-F][0-9a-fA-F]/'"${mac_address}"'/g' /etc/udev/rules.d/10-network.rules
else
  echo "No MAC address found. Skipping MAC address update."
fi


# 用户输入新的 IP 地址，避免重复修改相同的 IP
read -p "Enter Your IP: " ip
if [ "$ip" != "11" ]; then
  sed -i "s#^IPADDR=.*#IPADDR=192.168.6.${ip}#g" /etc/sysconfig/network-scripts/ifcfg-eth0
else
  echo "IP address is already set to 192.168.6.11, skipping IP change."
fi

# 如果 SSH 密钥已存在，则跳过密钥生成步骤
if [ ! -f /root/.ssh/id_rsa ]; then
  echo "SSH key does not exist. Generating SSH key..."
  ssh-keygen -t rsa -b 4096 -N "" -f /root/.ssh/id_rsa -C "root@$(hostname)"
else
  echo "SSH key already exists. Skipping SSH key generation."
fi

# 将 SSH 公钥添加到 authorized_keys 中
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys

#ssh-copy-id -i /root/.ssh/id_rsa.pub root@192.168.6.20

echo "Rebbot after 3s"
for i in {3..1}; do
  echo "$i"
  sleep 1
done
 
echo "Reboot Now！"
reboot

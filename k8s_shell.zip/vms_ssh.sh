#!/bin/bash

# ------------------------------------------------------------------
#  警告：本脚本仅用于教学和测试目的。
#  在生产环境中，请勿使用弱密码，请勿将密码硬编码在脚本中。
# ------------------------------------------------------------------

# 统一的root密码
ROOT_PASSWORD="123"

# 主机列表文件
HOSTS_FILE="hosts.txt"

# 检查 sshpass 是否安装
if ! command -v sshpass &> /dev/null; then
    echo "sshpass 未安装。请先安装：sudo dnf install sshpass -y 或 sudo apt install sshpass -y"
    exit 1
fi

# 检查主机列表文件是否存在
if [ ! -f "$HOSTS_FILE" ]; then
    echo "错误：找不到主机列表文件 '$HOSTS_FILE'。"
    echo "请创建该文件，并分行写入所有主机的IP地址。"
    exit 1
fi

# 记录当前主机列表，作为"老主机"
OLD_HOSTS=()
if [ -f "/tmp/existing_hosts.tmp" ]; then
    mapfile -t OLD_HOSTS < "/tmp/existing_hosts.tmp"
fi

#mapfile (在旧版本 Bash 中也叫 readarray)它用于将标准输入中的内容按行读取，并存储到指定的数组中

# 读取最新主机列表，作为"新主机"
mapfile -t ALL_HOSTS < "$HOSTS_FILE"
NEW_HOSTS=()
for host in "${ALL_HOSTS[@]}"; do
    is_new=true
    for old_host in "${OLD_HOSTS[@]}"; do
        if [ "$host" == "$old_host" ]; then
            is_new=false
            break
        fi
    done
    if $is_new; then
        NEW_HOSTS+=("$host")
    fi
done

if [ ${#NEW_HOSTS[@]} -eq 0 ]; then
    echo "没有发现新主机需要添加。脚本退出。"
    exit 0
fi

echo "--- 发现新主机：${NEW_HOSTS[@]} ---"

# 1. 为所有新主机生成SSH密钥对
for host in "${NEW_HOSTS[@]}"; do
    echo "正在主机 ${host} 上生成 SSH 密钥..."
    sshpass -p "$ROOT_PASSWORD" ssh -o StrictHostKeyChecking=no "root@$host" \
    "ssh-keygen -t rsa -b 4096 -N '' -f ~/.ssh/id_rsa"
done

echo "--- 密钥生成完成，开始全互联配置 ---"

# 2. 将所有老主机的公钥，复制到所有新主机上
for old_host in "${OLD_HOSTS[@]}"; do
    echo "正在从 ${old_host} 获取公钥..."
    sshpass -p "$ROOT_PASSWORD" scp -o StrictHostKeyChecking=no "root@$old_host:/root/.ssh/id_rsa.pub" "/tmp/id_rsa_${old_host}.pub"
    
    for new_host in "${NEW_HOSTS[@]}"; do
        echo "  - 将 ${old_host} 的公钥分发到新主机 ${new_host}..."
        sshpass -p "$ROOT_PASSWORD" ssh -o StrictHostKeyChecking=no "root@$new_host" \
        "mkdir -p ~/.ssh && chmod 700 ~/.ssh && cat >> ~/.ssh/authorized_keys" < "/tmp/id_rsa_${old_host}.pub"
    done
    rm "/tmp/id_rsa_${old_host}.pub"
done

# 3. 将所有新主机的公钥，复制到所有主机上（包括老主机和新主机自身）
for new_host in "${NEW_HOSTS[@]}"; do
    echo "正在从 ${new_host} 获取公钥..."
    sshpass -p "$ROOT_PASSWORD" scp -o StrictHostKeyChecking=no "root@$new_host:/root/.ssh/id_rsa.pub" "/tmp/id_rsa_${new_host}.pub"
    
    for host in "${ALL_HOSTS[@]}"; do
        echo "  - 将新主机 ${new_host} 的公钥分发到主机 ${host}..."
        sshpass -p "$ROOT_PASSWORD" ssh -o StrictHostKeyChecking=no "root@$host" \
        "mkdir -p ~/.ssh && chmod 700 ~/.ssh && cat >> ~/.ssh/authorized_keys" < "/tmp/id_rsa_${new_host}.pub"
    done
    rm "/tmp/id_rsa_${new_host}.pub"
done


echo "--- SSH 免密配置完成 ---"

# 4. 更新已处理主机列表
cp "$HOSTS_FILE" "/tmp/existing_hosts.tmp"

echo "正在测试新主机的SSH连接..."
for host in "${NEW_HOSTS[@]}"; do
    for target in "${ALL_HOSTS[@]}"; do
        echo "测试从 ${host} 到 ${target} 的连接..."
        sshpass -p "$ROOT_PASSWORD" ssh -o StrictHostKeyChecking=no "root@$host" \
        "ssh -o StrictHostKeyChecking=no 'root@$target' 'echo \"连接成功!\"'"
    done
done

echo "脚本执行完毕。现在你可以从任何主机SSH免密码连接到其他主机了."
#!/bin/bash

# ------------------------------------------------------------------
#  警告：本脚本用于教学和小规模集群。请合理配置生产环境权限。
# ------------------------------------------------------------------

ROOT_PASSWORD="123"              # 所有主机的 root 密码（建议后续改为 sudo 用户 + SSH）
HOSTS_FILE="hosts.txt"           # 主机 IP 列表文件
KEY_PATH="$HOME/.ssh/id_rsa"    # 中心节点 SSH 密钥路径
RECORD_FILE="/tmp/existing_hosts_centralized.tmp"

# 检查依赖
if ! command -v sshpass &> /dev/null; then
    echo "错误：sshpass 未安装。安装方法：sudo apt install sshpass -y 或 sudo dnf install sshpass -y"
    exit 1
fi

# 检查主机列表文件
if [ ! -f "$HOSTS_FILE" ]; then
    echo "错误：主机列表文件 $HOSTS_FILE 不存在"
    exit 1
fi

# 生成密钥（如果不存在）
if [ ! -f "$KEY_PATH" ]; then
    echo "生成新的 SSH 密钥对..."
    ssh-keygen -t rsa -b 4096 -N '' -f "$KEY_PATH"
fi

# 读取当前主机列表
mapfile -t CURRENT_HOSTS < "$HOSTS_FILE"

# 加载旧主机列表
OLD_HOSTS=()
if [ -f "$RECORD_FILE" ]; then
    mapfile -t OLD_HOSTS < "$RECORD_FILE"
fi

# 检测新增主机
NEW_HOSTS=()
for host in "${CURRENT_HOSTS[@]}"; do
    is_new=true
    for old_host in "${OLD_HOSTS[@]}"; do
        if [ "$host" == "$old_host" ]; then
            is_new=false
            break
        fi
    done
    if $is_new; then
        NEW_HOSTS+=("$host")
    fi
done

# 无新增主机
if [ ${#NEW_HOSTS[@]} -eq 0 ]; then
    echo "没有新增主机需要配置，脚本退出。"
    exit 0
fi

echo "--- 发现新增主机：${NEW_HOSTS[@]} ---"

# 分发公钥（并发）
for host in "${NEW_HOSTS[@]}"; do
    (
        echo "→ 正在将中心密钥分发到主机 $host ..."
        sshpass -p "$ROOT_PASSWORD" ssh-copy-id -i "$KEY_PATH.pub" -o StrictHostKeyChecking=no "root@$host" &> /dev/null

        if [ $? -eq 0 ]; then
            echo "✅ 公钥成功分发至 $host"
        else
            echo "❌ 公钥分发失败：$host"
        fi
    ) &
done

wait  # 等待所有并发任务完成

# 更新主机记录
cp "$HOSTS_FILE" "$RECORD_FILE"

echo "--- 全部新主机已配置完成 SSH 免密登录 ---"